# Data Modeller Part 2
The Data Modeller is a web application that provides users with various tools and functionalities related to data analysis, data modeling, and SQL code generation. The application is built using the Streamlit framework and leverages the Azure OpenAI service for generating responses and providing insights. The application has two main views: the "Business View" and the "Technical View."

## Features

### Business View

The Business View is designed for users who want to gain business insights from their datasets. It offers the following features:

- File Upload: Users can upload CSV files containing data, which will be displayed in tabular format.
- Predefined Questions: Users can ask predefined questions about the dataset, such as generating a data summary, identifying potential use cases, and more.
- Content Generation: The application uses the Azure OpenAI service to generate responses to predefined questions and displays them for users.
- Download Responses: Users can download the generated responses for future reference.

### Technical View

The Technical View is tailored for users with technical expertise who want to explore the dataset from a technical perspective. It includes the following features:

- File Upload: Users can upload CSV files, and the uploaded data is displayed in tabular format.
- SQL Query Input: Users can input an SQL query for data analysis.
- SQL Code Generation: The application generates SQL code based on user-input queries using the Azure OpenAI service.
- Predefined Questions: Users can ask predefined technical questions about the dataset, such as generating SQL schemas, tabular views of column information, and more.
- Content Generation: Similar to the Business View, the Technical View also generates responses to predefined questions using the Azure OpenAI service.
- Download Responses: Users can download the generated responses for future reference.

## How to Run

1. Clone this repository to your local machine
2. 3. Set up the required dependencies by locating the src directory running:
```bash
pip install -r requirements.txtpip install -r requirements.txt
```
3. Change the name of secrets.toml.example to secrets.toml, replace "API_KEY_EXAMPLE" with your API key
4. Run the application using the following command:
```bash
streamlit run app.py
```
5. The application will open in your web browser, and you can navigate through the different views and functionalities.

## Contributing
We welcome contributions to improve the source code. To contribute, please follow these steps:

1. Fork the repository.
2. Create a new branch for your feature or bug fix: git checkout -b feature-name.
3. Make your changes and commit them with descriptive commit messages.
4. Push your changes to your forked repository.
5. Create a pull request to the main repository's master branch.
   
## Note
Please keep in mind that parts of the code might be redacted or commented out, possibly containing specific functionalities or sensitive information. Make sure to customize the code to your specific requirements and ensure that you understand and comply with the Azure OpenAI usage terms.

---
<p align="center">
  Made with ❤️ by ACN Data Studio
</p>

import streamlit as st
import openai
import time
from data.Azure.azure_blob_reader import load_az_secure_glossary
openai.api_key = st.secrets["API_KEY"]

def load_mock_glossary_function():
    df_mock_glossary = load_az_secure_glossary()
    return df_mock_glossary

#tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
#model = BertModel.from_pretrained('bert-base-uncased')
#def generate_embeddings(text):
    # Tokenize the text
  #  inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True)

    # Pass the input through the model
  #  outputs = model(**inputs)

    # Extract the embeddings from the output
   # embeddings = outputs.last_hidden_state.mean(dim=1).squeeze().detach().numpy()

#    return embeddings
@st.cache_data
def generate_response(system_prompt, prompt_messages, model):
    response = openai.ChatCompletion.create(
        messages=[
            {'role': 'system', 'content': system_prompt},
            *prompt_messages,
        ],
        model=model,
        max_tokens=2048,
        temperature=0.5
    )
    return response['choices'][0]['message']['content'].strip()

def info():
    st.title("Data Modeller")
    st.header("Get Started")
    st.markdown(
        """The Data Modeller app is a powerful tool that leverages AI and LLMs to enhance data management. Some of its features include. \n
• Easily understand existing datasets with structured, human-readable descriptions and automated metadata management. \n
• Advanced capabilities include generating data product descriptions, creating data dictionaries and suggesting potential use cases and improvements, accelerating technical documentation creation. \n
• Transform functional data requirements into a comprehensive business data model. \n
• The Data Assistant can propose potential improvements in the structure/architecture of the data provided. \n
        """
        )
    st.header("Security and Compliance")
    st.markdown("This Data Modeller works by leveraging Azure OpenAI services and its APIs. For use cases that are sensitive and highly regulated in nature, we have compiled the important security highlights of Azure OpenAI:")
    st.markdown("""
• Data used to fine-tune models are stored in Azure Storage and are encrypted at rest. \n 
• User Prompts (including data uploaded from the UI) and its corresponding chat completions are stored in servers for 30 days, then deleted. \n 
• Access to this data are limited to Microsoft employees only in the case of Azure OpenAI service abuse by customer. \n 
• This 30 day data retention and Microsoft employee access can be removed by submitting a form to Microsoft defining the use-case. Once approved nothing will be retained in their servers. \n 
• Chat, completions, prompts are not used to train, test, retrain Azure OpenAI models \n • Currently, most of our prompts can produce good results from a well defined data dictionary, so redacting any further information from the data is being considered.""")
    st.markdown("[Source](https://learn.microsoft.com/en-us/legal/cognitive-services/openai/data-privacy?context=%2Fazure%2Fcognitive-services%2Fopenai%2Fcontext%2Fcontext)")        

def FDRBDM(model, metatag_system_prompt, questions):
    generate_button_enabled = False
    df_mock_glossary = []
    if "content_generated" not in st.session_state:
        st.session_state.content_generated = False
    glossaryexpander = st.expander("Click to Expand Data Glossary", expanded=False)
    fdrexpander = st.expander("Click to Expand FDR", expanded=False)
    conversation_history = []

    st.title("Business Data Model Generator")
    st.markdown("Upload your Data Glossary and Functional Data Requirements to get started")

    # Dropdown to choose between data glossary source
    upload_option = st.sidebar.selectbox("Select Data Glossary Source", ["Upload CSV from Cloud (Recommended)", "Upload local CSV"], key="glossary_upload")

    uploaded_glossary = []  
    # drag_and_drop_container = st.empty()

    #if upload_option == "Select Source":
     #   st.sidebar.markdown("<span style='color:red;'>Select Data Glossary Source.</span>", unsafe_allow_html=True)
    if upload_option == "Upload CSV from Cloud (Recommended)":
        # Button to trigger the loading
        # load_button = st.sidebar.button("Load Mock Glossary")

        # if load_button:
        #     # Show a spinner while loading
        #     with st.spinner("Connecting to Azure..."):
        #         time.sleep(2.5)

            df_mock_glossary = load_mock_glossary_function()

            # Check if the DataFrame is not empty
            if df_mock_glossary is None:
                st.sidebar.markdown("<span style='color:red;'>File Not Found. Select a Different Input.</span>", unsafe_allow_html=True)
            else:
            # Extract headers and content separately
                headers_content = f"Mock Glossary Headers: {', '.join(df_mock_glossary.columns)}"
                content = df_mock_glossary.to_csv(index=False)
                st.sidebar.markdown("<span style='color:Green;'>Loading Finished: Cloud Data Glossary</span>", unsafe_allow_html=True)
                # Add glossary information to conversation_history
                glossary_content = f"Loading Finished: Local Data Glossary\n\n{headers_content}\n\n```{content}```" 
                conversation_history.append({"role": "user", "content": glossary_content})
            st.sidebar.markdown("----")
    elif upload_option == "Upload local CSV":
        with glossaryexpander:
            uploaded_glossary = st.sidebar.file_uploader(
            "", accept_multiple_files=True)

            for uploaded_file in uploaded_glossary:
                code_txt = uploaded_file.getvalue()
                content = str(uploaded_file.name) + " " + str(code_txt)
                conversation_history.append({"role": "user", "content": content})
                st.write("Filename:", uploaded_file.name)
                st.code(code_txt.decode("utf-8"), language='python')
        st.sidebar.markdown("----")
    # Allow the user to choose input type if a file is uploaded or Azure file is selected

    if (uploaded_glossary and len(uploaded_glossary) == 1) or len(df_mock_glossary)!=0:
        upload_type = st.sidebar.selectbox("Select Requirements Source", ["Manual Input", "File Upload"],key="FDRupload")

        #if upload_type == "Select Source":
         #   st.sidebar.markdown("<span style='color:red;'>Select Source Type.</span>", unsafe_allow_html=True)
        
        if uploaded_glossary and (len(uploaded_glossary) > 1):
            st.sidebar.markdown("<span style='color:red;'>Upload Data Glossary File</span>", unsafe_allow_html=True)
        

        elif upload_type == "File Upload":
            with fdrexpander:
                uploaded_fdr = st.sidebar.file_uploader(
                "Select the Requirements File", accept_multiple_files=True)

                for uploaded_file in uploaded_fdr:
                    code_txt = uploaded_file.getvalue()
                    content = str(uploaded_file.name) + " " + str(code_txt)
                    conversation_history.append({"role": "user", "content": content})
                    st.write("Filename:", uploaded_file.name)
                    st.code(code_txt.decode("utf-8"), language='python')
            st.sidebar.markdown("----")
            if uploaded_fdr and len(uploaded_fdr) == 1:
                generate_button_enabled = True
            elif uploaded_fdr and len(uploaded_fdr) != 1:
                generate_button_enabled = False
                st.sidebar.markdown("<span style='color:red;'>Upload the Requirments File</span>", unsafe_allow_html=True)
        elif upload_type == "Manual input": 
            fdr_scope = st.sidebar.text_input("Requirement Scope ID", key="scope_id")
            fdr_feature = st.sidebar.text_input("Requirement Feature", key="fdr_feature")
            fdr_title = st.sidebar.text_input("Requirement Name",key="fdr_title")        
            fdr_summary = st.sidebar.text_input("Requirement Description",key="fdr_summary")        
            generate_button_enabled = False
            if fdr_title and fdr_summary:
                conversation_history.append({"role": "user", "content": fdr_scope and fdr_feature and fdr_title and fdr_summary})
                generate_button_enabled = True

        generate_button = st.sidebar.button("Generate Business Data Model", key="generate_button", disabled=not generate_button_enabled)
        storeResponses = ""
        qCount = 1
        if generate_button or st.session_state.content_generated:
            for q in questions:
                prompt_messages = [{"role": "user", "content" : message["content"]}
                                    for message in conversation_history]
                if "embeddings" in conversation_history[-1]:
                    prompt_messages[-1]["embeddings"]=conversation_history[-1]["embeddings"]
                
                prompt_messages.append({'role':'user','content': questions[q]})
                output = generate_response(
                    metatag_system_prompt, prompt_messages, model)
                storeResponses += f'Q{qCount}. ' + \
                    questions[q] + '\n\n' + output + '\n\n\n\n'
                qCount += 1
                with st.expander(questions[q]):
                    st.write(output)
                    if q in ['README', 'Code']:
                        st.button(f"Download {q}", key=f"download_{qCount}")  # Use a unique key
            # Combine all files and generate a single download button
            combined_files = '\n\n\n\n'.join([message["content"] for message in conversation_history if message["role"] == "user"])
            st.sidebar.download_button("Download All Files", data=combined_files)
            st.session_state.content_generated = True
        if st.session_state.content_generated:
            prompt = "\n".join([message["content"]
                                for message in conversation_history])
            st.sidebar.download_button(
                "Download Responses", data=storeResponses)



def BDMIDL(model, metatag_system_prompt, questions):
    if "content_generated" not in st.session_state:
        st.session_state.content_generated = False

    conversation_history = []

    st.title("Business Data Model Generator")
    st.markdown("Upload your BDM and data structure to get started")
    st.sidebar.markdown("----")

    uploaded_files = st.sidebar.file_uploader(
        "Select the database and BDM csvs file to interpret", accept_multiple_files=True)
    for uploaded_file in uploaded_files:
        code_txt = uploaded_file.getvalue()
        content = str(uploaded_file.name) + " " + str(code_txt)
        # dataframe = pd.read_csv(uploaded_file)
        conversation_history.append({"role": "user", "content": content})
        st.write("Filename:", uploaded_file.name)
        # st.table(dataframe)
        st.code(code_txt.decode("utf-8"), language='python')
    st.sidebar.markdown("----")

    # Check if multiple files have been uploaded
    if uploaded_files and len(uploaded_files) > 1:
        generate_button_enabled = True
        upload_message = ""
    elif uploaded_files and len(uploaded_files) == 1:
        generate_button_enabled = False
        upload_message = "<span style='color:red;'>Please upload at least one more file to enable content generation.</span>"
    else:
        generate_button_enabled = False
        upload_message = "<span style='color:red;'>Upload more than one file to get started.</span>"

    st.sidebar.markdown(upload_message, unsafe_allow_html=True)

    generate_button = st.sidebar.button("Generate Contents", key="generate_button", disabled=not generate_button_enabled)

    storeResponses = ""
    qCount = 1
    if generate_button or st.session_state.content_generated:
        for q in questions:
            prompt = "\n".join([message["content"]
                                for message in conversation_history])
            prompt += '\n' + questions[q]
            output = generate_response(
                metatag_system_prompt, prompt, model)
            storeResponses += f'Q{qCount}. ' + \
                questions[q] + '\n\n' + output + '\n\n\n\n'
            qCount += 1
            with st.expander(questions[q]):
                st.write(output)
                if q in ['README', 'Code']:
                    st.button(f"Download {q}", key=f"download_{qCount}")  # Use a unique key

        # Combine all files and generate a single download button
        combined_files = '\n\n\n\n'.join([message["content"] for message in conversation_history if message["role"] == "user"])
        st.sidebar.download_button("Download All Files", data=combined_files)

        st.session_state.content_generated = True

    if st.session_state.content_generated:
        prompt = "\n".join([message["content"]
                            for message in conversation_history])
        st.sidebar.download_button(
            "Download Responses", data=storeResponses)

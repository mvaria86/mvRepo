import streamlit as st
from datetime import datetime, timedelta
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
import pandas as pd

def load_az_secure_glossary():
    azure_blob_secrets = st.secrets['azure_blob']
    account_name = azure_blob_secrets['account_name']
    account_key = azure_blob_secrets['account_key']
    container_name = azure_blob_secrets['container_name']
    # Client to interact with blob
    connect_str = 'DefaultEndpointsProtocol=https;AccountName=' + account_name + ';AccountKey=' + account_key + ';EndpointSuffix=core.windows.net'
    blob_service_client = BlobServiceClient.from_connection_string(connect_str)

    # Use client to connect to container
    container_client = blob_service_client.get_container_client(container_name)

    blob_name_to_read = 'mock_glossary.csv'

    # Generate a shared access signature for the specified blob
    sas_i = generate_blob_sas(account_name=account_name,
                               container_name=container_name,
                               blob_name=blob_name_to_read,
                               account_key=account_key,
                               permission=BlobSasPermissions(read=True),
                               expiry=datetime.utcnow() + timedelta(hours=1))

    # Construct the SAS URL for the specified blob
    sas_url = 'https://' + account_name + '.blob.core.windows.net/' + container_name + '/' + blob_name_to_read + '?' + sas_i
    
    # Read the CSV file and return the DataFrame
    df_mock_glossary = pd.read_csv(sas_url)
    
    return df_mock_glossary

import streamlit as st
# from utils import BDMIDL
from utils import info, FDRBDM
from prompts import metatag_system_promptFDRBDM, questionsFDRBDM 
# from prompts import questionsBDMIDL, metatag_system_promptBDMIDL

def main():
    st.markdown(
        """
        <style>
        [data-testid=stSidebar] [data-testid=stImage]
        {
            text-align: center;
            display: block;
            margin-left: auto;
            margin-right: auto;
            width: 90%;
        }
        </style>
        """, 
        unsafe_allow_html=True
    )
    # with st.sidebar:
    #     st.image("images/heraLogo.png", width=75)

    menu = ["Info", "FDR -> BDM"
            # "BDM -> IDL
            ]
    
    choice = st.sidebar.selectbox("Select from our features", menu)


    # GPT Model Selecter
    

    #Dropdown Menu choices
    if choice == "Info":
        info()
    # elif choice == "Data Glossary -> FDR":
    #     GloFDR(model, metatag_system_promptGloFDR, questionsGloFDR)
    elif choice == "FDR -> BDM":
        model = st.sidebar.selectbox('Pick a model version',('gpt-3.5-turbo-16k', 'gpt-4','gpt-4-1106-preview'),key="fdrmodel")
        st.sidebar.markdown("----")
        FDRBDM(model, metatag_system_promptFDRBDM, questionsFDRBDM)
    # elif choice == "BDM -> IDL":
        # model = st.sidebar.selectbox('Pick a model version',('gpt-3.5-turbo-16k', 'gpt-4','gpt-4-1106-preview'),key="bdmmodel")
    #     BDMIDL(model, metatag_system_promptBDMIDL, questionsBDMIDL)
    @st.cache_data
    def square(x):
        return x**2
    @st.cache_data
    def cube(x):
        return x**3
    if choice in ["FDR -> BDM", "BDM -> IDL"] and st.sidebar.button("Clear Cache"):
        # Clear values from *all* all in-memory and on-disk data caches:
        # i.e. clear values from both square and cube
        st.cache_data.clear()



if __name__ == "__main__":
    main()

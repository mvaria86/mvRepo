import csv
import os

def calculate_and_divide_by_four(csv_file):
    total_characters = 0

    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        
        # Assuming the first row is the header
        header = next(reader)

        for row in reader:
            for token in row:
                total_characters += len(str(token))

    result = total_characters / 4
    print(f"Total characters in CSV: {total_characters}")
    print(f"Result after dividing by 4: {result}")

if __name__ == "__main__":
    # Replace 'your_file.csv' with the actual CSV file path
    csv_file_path = 'Specializations-18-December-2023.csv'

    if os.path.exists(csv_file_path):
        calculate_and_divide_by_four(csv_file_path)
    else:
        print(f"File '{csv_file_path}' not found.")

 
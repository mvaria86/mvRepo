import openai
import json
import PyPDF2  
import streamlit as st
import pandas as pd

##  Load configuaration and raw data
def load_config_and_data():
    with open('../data/specialisations.json', 'r') as file:
        skillsets = json.load(file)

    with open('config.json', 'r') as config_file:
        config = json.load(config_file)
        ak = config.get("openai_api_key")

        if ak is None:
            raise ValueError("OpenAI API key not found in the configuration file")
    return skillsets, ak


def ask_question(system, user, api_key) :

    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": user}
    ]

    if openai.__version__[0]:
        # API_VERSION is 1.X.X
        client = openai.OpenAI(api_key=api_key)
        response = client.chat.completions.create(model="gpt-3.5-turbo-16k",
                                                  messages=messages)
        response_message = response.choices[0].message.content

    else:
        openai.api_key = api_key
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-16k",
            messages=messages
        )
        response_message = response['choices'][0]['message']['content']
    return response_message



# full process flow

# STEP ZERO - load config etc.
def step_zero():
    return load_config_and_data()

# STEP ONE - extract experiences from Resume
def step_one(sys, user, cv, ak):

    reader = PyPDF2.PdfReader(f"../CV/{cv}")
    cv_text = ""
    for page in reader.pages:
        cv_text += page.extract_text()

    skills = ask_question(sys, f'{user} {cv_text}', api_key=ak)
    return skills.split(',')


# STEP TWO - select Specialisations for each experience
def step_two(sys, user, skill, skillsets, ak):
    system_prompt = f"{sys} {set([s['Specialization'] for s in skillsets])}"
    user_prompt = f'{user} {skill}'
    return ask_question(system_prompt, user_prompt, api_key=ak)

# STEP THREE - select the specific skill for each experience within a specialisation
def step_three(sys, user, skill, spec, skillsets, ak):
    system_prompt = f"{sys} {set([s['Skill Names'] for s in skillsets if s['Specialization'] == spec])}"
    user_prompt = f"{user} {skill}"
    return ask_question(system_prompt, user_prompt, api_key=ak)

def st_process():
    st.markdown("# Skills and Scheduling")

    cv_file = st.file_uploader('CV File:')

# try to load the prompts file if it is available
    prompts_file = 'prompts.txt'
    try:
        with open(prompts_file) as f:
            prompts = f.read()
    except IOError:
        prompts = None

    if prompts:
        p = prompts.split('//')
        with st.expander("Process CV file"):
            sys1 = st.text_area(label='System prompt', value=p[0])
            user1 = st.text_area(label='User prompt', value=p[1])
        with st.expander("Determine specialisation"):
            sys2 = st.text_area(label='System prompt', value=p[2])
            user2 = st.text_area(label='User prompt', value=p[3])

        with st.expander("Match to skills"):
            sys3 = st.text_area(label='System prompt', value=p[4])
            user3 = st.text_area(label='User prompt', value=p[5])
    else:

        with st.expander("Process CV file"):
            sys1 = st.text_area(label='System prompt', value=f"""
            You are an expert at reading CVs and extracting the most important skills from them.
            Read the attached CV and return at most ten kills.
            Just return the skill names in a comma-separated list, do not include any explanations
            """)
            user1 = st.text_area(label='User prompt', value=f"""Analyse this cv""")
        with st.expander("Determine specialisation"):
            sys2 = st.text_area(label='System prompt', value=f"""
        You are to classify the skill into one of the specialisations given.  
        Select the best match for the skill provided.
        Only return one value.  
        Select from the following list of specialisations:
            """)
            user2 = st.text_area(label='User prompt', value=f"My skillset includes ")

        with st.expander("Match to skills"):
            sys3 = st.text_area(label='System prompt', value=f"""
            You are to classify the skill given as one of more of the following skills.  
            Select the best three matches for the skill provided. 
            Just return the skill names.  Do not return an explanation of your reasoning.
            Return the values as a comma-separated list.
            Select from the following list of skills:
            """)
            user3 = st.text_area(label='User prompt', value=f"My skills include  ")

    col1, col2 = st.columns(2)
    with col1:
        proc = st.button('Process')
    with col2:
        data = f"{sys1}//{user1}//{sys2}//{user2}//{sys3}//{user3}"
        save = st.download_button('Save Prompts', data=data, file_name=prompts_file )



    data = []

    if proc:
        if cv_file:
            skillsets, ak = step_zero()
            st.toast('Loaded config')

            skills = step_one(sys1, user1, cv_file.name, ak)
            st.toast('Completed Step One')

            # for table output
            total_skills = len(skills)
            cnt = 0
            for skill in skills:
                cnt += 1
                spec = step_two(sys2, user2, skill, skillsets, ak)
                st.toast(f'Completed Step Two for skill {cnt} of {total_skills}')

                my_skills = step_three(sys3,user3,skill,spec,skillsets, ak)
                st.toast(f'Completed Step Three for skill {cnt} of {total_skills}')

                data.append([skill, spec, my_skills])
            table = pd.DataFrame(data=data,
                                 columns=['Experience', 'Specialization', 'Skills'])
            st.dataframe(table)
        else:
            st.warning("Load CV file before processing")

st_process()


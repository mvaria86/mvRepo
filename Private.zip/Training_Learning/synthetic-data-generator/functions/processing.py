import re, ast, random
from itertools import product

def extract_relations_list_of_lists(value):
    marker = "# Output"
    start_index = value.find(marker) + len(marker)
    list_of_lists_str_value = value[start_index:].strip()
    list_of_lists = ast.literal_eval(list_of_lists_str_value)
    return list_of_lists

def get_column_options(response):
    dict_response = ast.literal_eval(response)
    list_of_listcategories = []
    for key in dict_response:
        if key != "relations":
            list_of_listcategories.append(dict_response[key][1])
    return list_of_listcategories

def create_empty_list_with_options(value, no_of_cols):
    initial_lists = []
    for x in range(len(value)):
        if x > 1:
            combination_list = [None for num in range(no_of_cols)]
            for y in range(len(value[0])):
                combination_list[value[0][y]] = value[x][y]
            initial_lists.append(combination_list)
    return initial_lists


def filter_sequences_efficient(sequences, filter_list):
    # This function now explicitly mentions handling sequences, which includes both lists and tuples.
    return [sequence for sequence in sequences if all(sequence[i] == filter_list[i] or filter_list[i] is None for i in range(len(filter_list)))]

def get_all_possible_combinations(options, must_have):
    sequences = list(product(*options))
    all_possible_combinations = []
    for criteria in must_have:
        #print(criteria)
        criteria_possible_combinations = filter_sequences_efficient(sequences,criteria)
        #print(len(criteria_possible_combinations))
        all_possible_combinations = all_possible_combinations + criteria_possible_combinations
    print("count of all possible combinations: ",len(all_possible_combinations))
    return all_possible_combinations

def select_random_lists(list_all_combinations_lists, n):
    count_list = len(list_all_combinations_lists)
    if not list_all_combinations_lists:
        print("The list of lists is empty.")
    elif n >=  count_list:
        selected_lists_as_lists = list_all_combinations_lists
    else:
        # Ensure n does not exceed the number of available lists
        n = min(n, count_list)

        # Shuffle the list of lists to ensure randomness without modifying the original list
        shuffled_indices = list(range(count_list))
        random.shuffle(shuffled_indices)

        selected_indices = shuffled_indices[:n]
        selected_lists = [list_all_combinations_lists[i] for i in selected_indices]

        # Convert tuples back to lists if necessary
        selected_lists_as_lists = [list(lst) for lst in selected_lists]

        # Remove selected lists from the original lists
        for index in sorted(selected_indices, reverse=True):
            del list_all_combinations_lists[index]

        print("Selected lists:", len(selected_lists_as_lists))
        print("Remaining lists:", count_list)
        return selected_lists_as_lists, list_all_combinations_lists
    
def get_row_runs(selected_lists_as_lists,n):
    count_selected = len(selected_lists_as_lists)
    base_print = n // count_selected
    extra_needed = n % count_selected

    list_number_of_runs = [base_print for x in selected_lists_as_lists]
    for x in range(extra_needed):
        list_place = random.randint(0,count_selected-1)
        list_number_of_runs[list_place] += 1
    return list_number_of_runs
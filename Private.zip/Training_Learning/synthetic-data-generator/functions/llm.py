from openai import AzureOpenAI
from functions.keyvault import get_secret

# Open AI Functions
tokens_model = get_secret("tokensmodel")
chatgpt4_model_name = get_secret("oaiukmodel4")
chatgpt35_model_name = get_secret("oaiukmodel")
chatgpt432k_model_name = get_secret("oaiukmodel432k")

clientuk = AzureOpenAI(
  api_key = get_secret("oaiukkey"),  
  api_version = get_secret("oaiukversion"),
  azure_endpoint = get_secret("oaiukbase")
)

def create_request(system_prompt, user_prompt,examples=None):
    # the example dictionaries can be removed and additional dictionaries can be added to conversation as necessary
    request = [
        {"role": "system", "content": system_prompt}]
    if examples:
        for messages in examples:
            request.append({"role": "user", "content": messages[0]})
            request.append({"role": "assistant", "content": messages[1]})
    request.append({"role": "user", "content": user_prompt})
    return request

def send_request(request_message, model_name, temperature=0.2, presence_penalty=0.0, max_tokens=5000):

    response = clientuk.chat.completions.create(
        model=model_name,
        messages=request_message,
        temperature=temperature,
        max_tokens=max_tokens,
        top_p=0.95,
        frequency_penalty=0,
        presence_penalty=presence_penalty,
        stop=None)

    # Updated way to access the response content and usage information
    response_content = response.choices[0].message.content

    return response_content
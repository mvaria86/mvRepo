from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient
import os

# Keyvault code
key_vault_url = os.getenv("key_vault_url")

client_id = os.getenv("client_id")
client_secret = os.getenv("client_secret")
tenant_id = os.getenv("tenant_id")

# Create a SecretClient using Azure Identity for authentication
credentials = ClientSecretCredential(client_id=client_id, client_secret=client_secret, tenant_id=tenant_id)
secret_client = SecretClient(vault_url=key_vault_url, credential=credentials)


def get_secret(value):
    secret = secret_client.get_secret(value)
    return secret.value
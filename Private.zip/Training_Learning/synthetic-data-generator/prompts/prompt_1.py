import re
from functions.llm import create_request
system_prompt_initial = """
You are a data engineer specialised in Python and Pandas. You are an expert in understanding the wider context of data and 
using critical thinking to identify diverse and realistic and consistent kinds of data. You have an eye for detail.

The user will provide a pandas dataframe which has been converted into json. You will analyse the data and column names, 
understand any relations between columns and 
describe the different categories of realistic data that each column can hold. For example, in a name column for a table of people's details, 
you should include a wide and diverse range of name origins, such as English or Arabic, etc. Or for an age column, you will 
include the different age ranges. For relations, if there is an age column and a date of birth column, then you should identify the relation between these two columns, i.e. if the date of birth is 01/01/2000 and the current year is 2024, 
then the age should reflect this and be 24.
Think critically understanding the table schema and context provided. Be specific for each category and include atleast 5 categories,
and describe the formatting exactly the same as the user given json data. E.g. if a date of birth is given using slashes, then the categories
should also use slashes. Be inclusive and diverse and consistent in the categories.

You will create a python dictionary where a key called relations where the value is a string describing all logical relationships 
that can be identified between the columns, not including the id columns, in the table and it should only describe how these columns influence the data of the columns it relates to. Do not mention columns which have no specific relations to other columns. Ignore the ID columns in the relations value unless specifically mentioned
 in the user given context. In the relations value, do not mention the ID columns unless the ID columna have specifically been stated in the context. Every other key in the dictionary is a column name and its value is a python list where the first item in the 
list is describing the various data that can be identified for that column, and the second item in the list is a list where each value is a
 category of the column data and the formatting to go with it. Your response will only contain the Python dictionary.
"""

system_prompt_initial = re.sub(r'\s+', ' ', system_prompt_initial)

system_prompt_example = """
# Example output
{'Description': 'The age column is equal to 2024 minus the year in the DateOfBirth column.'
'DateOfBirth':['Date values representing the birth date of the party. Can range from mid 1900s to current year minus 18.',['01/01/2004 to 31/12/2005','01/01/1994 to 31/12/2003','01/01/1984 to 31/12/1993','01/01/1974 to 31/12/1983','01/01/1964 to 31/12/1973','01/01/1954 to 31/12/1963','01/01/1944 to 31/12/1953','01/01/1934 to 31/12/1943','01/01/1924 to 31/12/1933']]}
"""

system_prompt = system_prompt_initial #+ "\n\n" + system_prompt_example

example_input = """
# Pandas dataframe converted to json:
[{'Name': 'Sam', 'Age': 38, 'Gender': 'Male'},
{'Name': 'Nina', 'Age': 40, 'Gender': 'Female'},
{'Name': 'Ahmed', 'Age': 22, 'Gender': 'Male'},
{'Name': 'Sarah', 'Age': 24, 'Gender': 'Female'},
{'Name': 'Layla', 'Age': 34, 'Gender': 'Female'}]
    
# Context:
There should only be English Names or Arabic names, and there should be ages between 30 and 40 or ages between 20 and 30.

# Request:
If possible, provide atleast 5 categories per column. Ensure categories are descriptive and describe the formatting exactly the same as the values in the Pandas dataframe converted to json while the category description aligns to the column names in the Pandas dataframe converted to json and each of the category descriptions are realistic and consistent. In the relations value, do not mention the ID columns unless the ID columns have specifically been stated in the context. Do include a key for each ID column.
"""

example_output = """
{'relations': 'The gender column is related to the name column. The gender should be reflective of the gender', 
'Name': ['This column contains the name of the person. These names should be of either English origin or Arabic origin.', 
['English Names, formatted as forename', 'Arabic Names, formatted as forename']], 
'Age': ['This column contains the age of the person. The age must be over 18', 
['20 to 30, formatted as an integer', '30 to 40, formatted as an integer']],
'Gender': ['This column contains the gender of the person. The gender can be either female or male.', 
['Male, formatted as Male', 'Female, formatted as Female']]}
"""

request = """If possible, provide atleast 5 categories of possible values per column. Ensure categories are descriptive and 
describe the formatting exactly the same as the values in the Pandas dataframe converted to json while the 
category description aligns to the column names in the Pandas dataframe converted to json and each of the category descriptions are realistic and consistent. 
In the relations value, do not mention the ID columns unless the ID columns have specifically been stated in the context."""

request = re.sub(r'\s+', ' ', request)

def create_user_prompt(json_sample,table_context):
    table_context = re.sub(r'\s+', ' ', table_context)
    user_prompt = f"""
    # Pandas dataframe converted to json:
    {json_sample}
        
    # Context:
    {table_context}

    # Request:
    {request}
    """
    return user_prompt

def create_request_prompt_1(json_sample,table_context=""):
    user_prompt = create_user_prompt(json_sample,table_context)
    examples =[[example_input,example_output]]
    request = create_request(system_prompt, user_prompt,examples)
    return request
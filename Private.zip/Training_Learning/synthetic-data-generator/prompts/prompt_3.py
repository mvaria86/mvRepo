import re
from functions.llm import create_request

system_prompt_initial = """
You are a data engineer specialised in Python and Pandas. You are an expert in understanding the wider context of data and 
using critical thinking to create a diverse dataset.

The user will provide a python dictionary where the relations value is a string describing all relationships 
between columns. Every other key in the dictionary is a column name and its value is a python list where the first item in the 
list is describing the various data that can be identified for that column, and the second item in the list is a list 
containing each category of data and its formatting.

You will create a list of strings, where each string describes a row of values, stating what category each column will fit into,
ensuring data your descriptions take into account the relations between columns, and the description and formatting of the category of data. The string will also contain an example based on the
user given json data, to start the completion of the table data.
"""
# You will also be given combinations for the outputs which you will need to analyse based on the relations and additional context to identify which combinations are feasable. Based on the possible combinations which are feasable,
system_prompt_initial = re.sub(r'\s+', ' ', system_prompt_initial)

example_input = """
# Python dictionary describing the table data:
{'relations': 'The gender column is related to the name column. The gender should be reflective of the gender', 
 'Name': ['This column contains the name of the person. These names should of either English origin or Arabic origin.', 
 ['English Names, formatted as forename', 'Arabic Names, formatted as forename']], 
 'Age': ['This column contains the age of the person. The age must be over 18', 
 ['20 to 30, formatted as an integer', '30 to 40, formatted as an integer']],
 'Gender': ['This column contains the gender of the person. The gender can be either female or male.', 
 ['Male, formatted as Male', 'Female, formatted as Female']]}

# Json data of the pandas dataframe
[{'Name': 'Sam', 'Age': 38, 'Gender': 'Male'},
{'Name': 'Nina', 'Age': 40, 'Gender': 'Female'},
{'Name': 'Ahmed', 'Age': 22, 'Gender': 'Male'},
{'Name': 'Sarah', 'Age': 24, 'Gender': 'Female'},
{'Name': 'Layla', 'Age': 34, 'Gender': 'Female'}]

# Combinations of categories: each list is using in an Instruct to descrive the data we are expecting
[['English Names, formatted as forename','20 to 30, formatted as an integer','Male, formatted as Male'],
['English Names, formatted as forename','20 to 30, formatted as an integer','Female, formatted as Female'],
['English Names, formatted as forename','30 to 40, formatted as an integer','Male, formatted as Male'],
['English Names, formatted as forename','30 to 40, formatted as an integer','Female, formatted as Female'],
['Arabic Names, formatted as forename','20 to 30, formatted as an integer','Male, formatted as Male'],
['Arabic Names, formatted as forename','20 to 30, formatted as an integer','Female, formatted as Female'],
['Arabic Names, formatted as forename','30 to 40, formatted as an integer','Male, formatted as Male'],
['Arabic Names, formatted as forename','30 to 40, formatted as an integer','Female, formatted as Female']]

# Combination counts: how many dictionaries we want for each combination of categories
[5,5,5,5,5,5,5,5]

# Additional Context:
Ensure the Instruct and Output in each string accurately reflects the relations value in the python dictionary. Ensure the output reflects a random value which meets the column category description and formatting.
"""
# 
example_output = """
['''Instruct: The Output should only be a python list of 5 dictionaries, with each dictionary containing: A random Male English name, formatted as forename; a random age between 30 and 40, formatted as an integer; a Male gender which reflects the name, formatted as Male.
Output: [    {'Name': 'Jack', 'Age': 28, 'Gender': 'Male'},''',
'''Instruct: The Output should only be a python list of 5 dictionaries, with each dictionary containing: A random Female English name, formatted as forename; a random age between 30 and 40, formatted as an integer; a Female gender which reflects the name, formatted as Female.
Output: [    {'Name': 'Sarah', 'Age': 22, 'Gender': 'Female'},''',
'''Instruct: The Output should only be a python list of 5 dictionaries, with each dictionary containing: A random Male English name, formatted as forename; a random age between 20 and 30, formatted as an integer; a Male gender which reflects the name, formatted as Male.
Output: [    {'Name': 'Ben', 'Age': 33, 'Gender': 'Male'},''',
'''Instruct: The Output should only be a python list of 5 dictionaries, with each dictionary containing: A random Female English name, formatted as forename; a random age between 20 and 30, formatted as an integer; a Female gender which reflects the name, formatted as Female.
Output: [    {'Name': 'Lisa', 'Age': 36, 'Gender': 'Female'},''',
'''Instruct: The Output should only be a python list of 5 dictionaries, with each dictionary containing: A random Male Arabic name, formatted as forename; a random age between 30 and 40, formatted as an integer; a Male gender which reflects the name, formatted as Male.
Output: [    {'Name': 'Ali', 'Age': 21, 'Gender': 'Male'},''',
'''Instruct: The Output should only be a python list of 5 dictionaries, with each dictionary containing: A random Female Arabic name, formatted as forename; a random age between 30 and 40, formatted as an integer; a Female gender which reflects the name, formatted as Female.
Output: [    {'Name': 'Fatima', 'Age': 27, 'Gender': 'Female'},''',
'''Instruct: The Output should only be a python list of 5 dictionaries, with each dictionary containing: A random Male Arabic name, formatted as forename; a random age between 20 and 30, formatted as an integer; a Male gender which reflects the name, formatted as Male.
Output: [    {'Name': 'Usman', 'Age': 39, 'Gender': 'Male'},''',
'''Instruct: The Output should only be a python list of 5 dictionaries, with each dictionary containing: A random Female Arabic name, formatted as forename; a random age between 20 and 30, formatted as an integer; a Female gender which reflects the name, formatted as Female.
Output: [    {'Name': 'Halima', 'Age': 34, 'Gender': 'Female'},''']
"""

system_prompt = system_prompt_initial

def create_user_prompt(python_dictionary_description,json_sample_table,combinations, combination_counts):
    context = """The current year is 2024. Ensure the Instruct and Output in each string accurately reflects the relations 
    value in the python dictionary. Ensure the output reflects a random value which meets the column category description and formatting. Give me strings which reflect the user given combinations only if they accurately reflect 
    the python dictinoary describing the table data including the relations and context, as well as your own understanding 
    of the data. """

    context = re.sub(r'\s+', ' ', context)

    user_prompt = f"""
    # Python dictionary describing the table data:
    {python_dictionary_description}

    # Json data of the pandas dataframe
    {json_sample_table}

    # Combinations of categories: each list will be used in an Instruct to describe the data we are expecting
    {combinations}
    
    # Combination counts: how many dictionaries we want for each combination of categories
    {combination_counts}

    # Additional Context:
    {context}
    """
    return user_prompt

def create_request_prompt_3(python_dictionary_description,json_sample_table,combinations, combination_counts):
    user_prompt = create_user_prompt(python_dictionary_description,json_sample_table,combinations, combination_counts)
    examples = [[example_input,example_output]]
    request = create_request(system_prompt, user_prompt, examples)
    return request
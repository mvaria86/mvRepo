import re
from functions.llm import create_request

system_prompt = """
You are a data engineer specialised in Python and Pandas. You are an expert in understanding the wider context of data.

The user will provide a dictionary, which contains a 'relations' key where the value is a description of all columns that have any relations
as well as any restrictions on the data. The rest of the keys are columns where the value is a list. Each list will contain the 
description of the column in the first value, and the second value is a list containing all possible values for the column.

Based on the columns and relations, you will output a lists of lists. Based on the columns mentioned in the relations column you 
will create lists the size of the number of columns and the same order of the columns and you will only make combinations for the columns mentioned in relations column 
while making the value as None for every other column.
"""

example_input_1 = """
# context
I have provided a dictionary which has a 'relations' key where the value is a description of all columns in the table that have any relations as well as any restrictions on the data. The rest of the keys are columns in the table where the value is a list. Each list will contain the  description of the column in the first value, and the second value is a list containing all categories of possible values for the column.

# request
Based on the columns and relations, you will output a lists of lists. Based on the columns mentioned in the relations column you will create lists in the same order of the columns mentioned and you will only make combinations for the columns mentioned in relations column. I want every possible combination which meets the criterion set in the relations value. For example, if the age column values are either over 18 or under 18; and the restricted column values are either T or F; and the relations column states the restricted column is related to the age column, in that the restricted column is only T if the age column is over 18; then the output should be a list of two lists of values for each column where the first list has resticted column value as T and age column as over 18 and the second list has restricted column value as F and age column is under 18. This is every possible combination based on the limitation described in the relations column. Based on the analysis, the first list in the output should be the index for each value in the complete list of columns, and the second list should be the column names. This analysis should be reflected in the output. Think step by step. I will pay you a bonus if you do well.

# dictionary
{'relations': 'The gender column is related to the name column. The gender should be reflective of the name', 
'ID': ['This column contains the unique id of each record.',
['1 to 10, formatted as an integer', '11 to 20, formatted as an integer', '21 to 30, formatted as an integer']],
'Name': ['This column contains the name of the person. These names should be of either English origin or Arabic origin.', 
['English Names, formatted as forename', 'Arabic Names, formatted as forename']], 
'Age': ['This column contains the age of the person. The age must be over 18', 
['20 to 30, formatted as an integer', '30 to 40, formatted as an integer']],
'Gender': ['This column contains the gender of the person. The gender can be either female or male.', 
['Male, formatted as Male', 'Female, formatted as Female']]}
"""

example_output_1 = """
# Analysis
Relations value states the name column is related to the gender column. Therefore, ignoring the relations key, because name is the second key in the dictionary then the second value in the list should contain the different names values given and because gender is the fourth key in the dictionary then the fourth value in the list should contain the different names values given. There are no other restrictions from the relations value. This analysis should be reflected in the output.

# Must have
The output must have every possible combination between name and gender. For example, ['English Names','Male']. The output must meet this criteria.

# Output
[[1,3],
['Name','Gender'],
['English Names, formatted as forename','Male, formatted as Male'],
['Arabic Names, formatted as forename','Male, formatted as Male'],
['English Names, formatted as forename','Female, formatted as Female'],
['Arabic Names, formatted as forename','Female, formatted as Female']]
"""

example_input_2 = """
# request
Based on the columns and relations, you will output a lists of lists. Based on the columns mentioned in the relations column you will create lists in the same order of the columns mentioned and you will only make combinations for the columns mentioned in relations column. I want every possible combination which meets the criterion set in the relations value. For example, if the age column values are either over 18 or under 18; and the restricted column values are either T or F; and the relations column states the restricted column is related to the age column, in that the restricted column is only T if the age column is over 18; then the output should be a list of two lists of values for each column where the first list has resticted column value as T and age column as over 18 and the second list has restricted column value as F and age column is under 18. This is every possible combination based on the limitation described in the relations column. Based on the analysis, the first list in the output should be the index for each value in the complete list of columns, and the second list should be the column names. This analysis should be reflected in the output. Think step by step. I will pay you a bonus if you do well.

# dictionary
{'relations': 'The country column is related to the language column. Each country corresponds to a primary language spoken in that country.',
'ID': ['This column contains the unique id of each record.',
['1 to 5, formatted as an integer', '6 to 10, formatted as an integer', '11 to 15, formatted as an integer']],
'Country': ['This column contains the name of the country.', 
['USA, formatted as USA', 'France, formatted as France', 'China, formatted as China']],
'Language': ['This column contains the primary language spoken in the country.',
['English, formatted as English', 'French, formatted as French', 'Mandarin, formatted as Mandarin']],
'Population': ['This column contains the population of the country.',
['100M to 200M, formatted as an integer followed by M', '200M to 300M, formatted as an integer followed by M', '300M to 400M, formatted as an integer followed by M']]}
"""

example_output_2 = """
# Analysis
Relations value states the country column is related to the language column. Therefore, ignoring the relations key, because country is the second key in the dictionary then the second value in the list should contain the different country values given and because language is the third key in the dictionary then the third value in the list should contain the different language values given. There are is a restriction of each country having only one primary language. This analysis should be reflected in the output.

# Must have
The output must have each country having only one language. For example, ['USA', 'English']. The output must meet this criteria.

# Output
[[1,2],
['Country','Language'],
['USA, formatted as USA', 'English, formatted as English'],
['France, formatted as France', 'French, formatted as French'],
['China, formatted as China', 'Mandarin, formatted as Mandarin']]
"""

example_input_3 = """
# request
Based on the columns and relations, you will output a lists of lists. Based on the columns mentioned in the relations column you will create lists in the same order of the columns mentioned and you will only make combinations for the columns mentioned in relations column. I want every possible combination which meets the criterion set in the relations value. For example, if the age column values are either over 18 or under 18; and the restricted column values are either T or F; and the relations column states the restricted column is related to the age column, in that the restricted column is only T if the age column is over 18; then the output should be a list of two lists of values for each column where the first list has resticted column value as T and age column as over 18 and the second list has restricted column value as F and age column is under 18. This is every possible combination based on the limitation described in the relations column. Based on the analysis, the first list in the output should be the index for each value in the complete list of columns, and the second list should be the column names. This analysis should be reflected in the output. Think step by step. I will pay you a bonus if you do well.

# dictionary
{'relations': 'The Genre column is related to the Format column. Fiction genre is available only in Hardcover and Paperback formats.',
'ID': ['This column contains the unique id of each record.',
['201 to 205, formatted as an integer', '206 to 210, formatted as an integer', '211 to 215, formatted as an integer']],
'ForeignID': ['This column contains the foreign id of each record which references another table.',
['1 to 5, formatted as an integer', '6 to 10, formatted as an integer', '11 to 15, formatted as an integer']],
'Genre': ['This column contains the genre of the book.', 
['Fiction, formatted as Fiction', 'Non-fiction, formatted as Non-fiction', 'Science Fiction, formatted as Science Fiction']],
'Format': ['This column contains the format of the book.', 
['Hardcover, formatted as Hardcover', 'Paperback, formatted as Paperback', 'E-book, formatted as E-book']],
'Price': ['This column contains the price of the book.', 
['Low, formatted as an integer', 'Medium, formatted as an integer', 'High, formatted as an integer']]}
"""

example_output_3 = """
# Analysis
Relations value states the genre column is related to the format column. Therefore, ignoring the relations key, because genre is the third key in the dictionary then the third value in the list should contain the different genre values given and because format is the fourth key in the dictionary then the fourth value in the list should contain the different format values given. There is a restiction which is that the Fiction Genre is only available in Hardcover and Paperback format. This analysis should be reflected in the output.

# Must have
The output must have every possible combination between genre and format while meeting the following criteria: The 'Fiction' genre must only be combined with 'Hardback' format and 'Paperback' format. For example, [‘Fiction’,’Hardback’]. The output must meet this criteria.

# Output
[[2,3],
['Genre','Format'],
['Fiction, formatted as Fiction', 'Hardcover, formatted as Hardcover'],
['Fiction, formatted as Fiction', 'Paperback, formatted as Paperback'],
['Non-fiction, formatted as Non-fiction', 'Hardcover, formatted as Hardcover'],
['Non-fiction, formatted as Non-fiction', 'Paperback, formatted as Paperback'],
['Non-fiction, formatted as Non-fiction', 'E-book, formatted as E-book'],
['Science Fiction, formatted as Science Fiction', 'Hardcover, formatted as Hardcover'],
['Science Fiction, formatted as Science Fiction', 'Paperback, formatted as Paperback'],
['Science Fiction, formatted as Science Fiction', 'E-book, formatted as E-book']
]
"""

examples = [[example_input_1,example_output_1],[example_input_3,example_output_3]]#,[example_input_3,example_output_3]]

def create_user_prompt(dictionary):
    user_input = f"""
    # request
    Based on the columns and relations, you will output a lists of lists. Based on the columns mentioned in the relations column you will create lists in the same order of the columns mentioned and you will only make combinations for the columns mentioned in relations column. I want every possible combination  which meets the criterion set in the relations value. For example, if the age column values are either over 18 or under 18; and the restricted column values are either T or F; and the relations column states the restricted column is related to the age column, in that the restricted column is only T if the age column is over 18; then the output should be a list of two lists of values for each column where the first list has resticted column value as T and age column as over 18 and the second list has restricted column value as F and age column is under 18. This is every possible combination based on the limitation described in the relations column. Based on the analysis, the first list in the output should be the index for each value in the complete list of columns, and the second list should be the column names. This analysis should be reflected in the output. Think step by step. I will pay you a bonus if you create every possible combination while adhering to the restrictions given.

    # dictionary
    {dictionary}
    """
    return user_input

def create_request_prompt_2(dictionary):
    user_prompt = create_user_prompt(dictionary)
    request = create_request(system_prompt, user_prompt, examples)
    return request
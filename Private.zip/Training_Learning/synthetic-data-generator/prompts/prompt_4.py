import re
from functions.llm import create_request

system_prompt_initial = """
You are an experienced python developer who can accurately create lists of dictionaries containing data based on 
the instruct given by the user. You will be creative in the data you output while adhering to the instruct given by 
the user.
"""

system_prompt = re.sub(r'\s+', ' ', system_prompt_initial)

example_input = """
# Request
Follow the Instruct to create a python list of dictionaries and for each value in the dictionary you must adhere to the descriptions given. Use the Output as an example and in your response give data different to the Output while still adhering to the Instruct.

Instruct: The Output should only be a python list of 3 dictionaries, with each dictionary containing: A random English name, formatted as forename surname; a random diagnosis code, formatted as a string; a random procedure code, formatted as an integer; a random total charge between $200.00 and $250.00, formatted as a float; and a random insurance claim amount less than or equal to the total charge, formatted as a float.
Output: [{'Patient Name': 'Oliver Smith', 'Diagnosis Code': 'B34.2', 'Procedure Code': 99214, 'Total Charge': 225.0, 'Insurance Claim Amount': 200.0},
"""

example_output = '''
[{"Patient Name": "Jack Wills", "Diagnosis Code": "C32.2", "Procedure Code": "99215", "Total Charge": 150.0, "Insurance Claim Amount": 120.0}, 
{"Patient Name": "Emma Lee", "Diagnosis Code": "H30.1", "Procedure Code": "72450", "Total Charge": 200.0, "Insurance Claim Amount": 180.0}, 
{"Patient Name": "Nathan Johnson", "Diagnosis Code": "J91.9", "Procedure Code": "99216", "Total Charge": 50.0, "Insurance Claim Amount": 40.0}]
'''

def create_use_prompt(instruct):
    input = f"""
            # Request
            Follow the Instruct to create a python list of dictionaries and for each value in the dictionary you must adhere to the descriptions and formatting given. Use the Output as an example and in your response give data different to the Output while still adhering to the Instruct.

            {instruct}
            """
    return input


def create_request_prompt_4(instruct):
    user_prompt = create_use_prompt(instruct)
    examples = [[example_input,example_output]]
    request = create_request(system_prompt, user_prompt, examples)
    return request
import pandas as pd, ast
from functions.llm import send_request, chatgpt4_model_name,chatgpt35_model_name,chatgpt432k_model_name
from functions.processing import extract_relations_list_of_lists,get_column_options,create_empty_list_with_options,get_all_possible_combinations,select_random_lists,get_row_runs
from prompts.prompt_1 import create_request_prompt_1
from prompts.prompt_2 import create_request_prompt_2
from prompts.prompt_3 import create_request_prompt_3
from prompts.prompt_4 import create_request_prompt_4
import os

def stage_0(df_sample):
    int_df_col_count = df_sample.shape[1]
    json_sample = df_sample.to_json(orient = 'records')
    return int_df_col_count, json_sample

def stage_1(json_sample,table_context,folder_name):
    request_1 = create_request_prompt_1(json_sample,table_context)
    response_1 = send_request(request_1, chatgpt4_model_name, temperature=0.4)
    with open(f'{folder_name}/stage_1.txt', 'w') as file:
        file.write(response_1)
    column_options = get_column_options(response_1)
    return response_1, column_options
    
def stage_2(response_1,folder_name):
    request_2 = create_request_prompt_2(response_1)
    response_2 = send_request(request_2, chatgpt4_model_name, temperature=0.3)
    with open(f'{folder_name}/stage_2.txt', 'w') as file:
        file.write(response_2)
    return response_2

def stage_2_5(response_2, int_df_col_count,column_options,number_of_rows,folder_name):
    list_of_lists=extract_relations_list_of_lists(response_2)
    print(list_of_lists)
    empty_list_relations = create_empty_list_with_options(list_of_lists,int_df_col_count)
    print(empty_list_relations)
    all_possible_options = get_all_possible_combinations(column_options,empty_list_relations)

    selected_lists_as_lists, list_all_combinations_lists = select_random_lists(all_possible_options, number_of_rows)
    with open(f'{folder_name}/stage_2_5.txt', 'w') as file:
        file.write(str(selected_lists_as_lists))
    list_number_of_runs = get_row_runs(selected_lists_as_lists,number_of_rows)
    return selected_lists_as_lists, list_number_of_runs

def stage_3(n,selected_lists_as_lists,response_1,json_sample,list_number_of_runs,folder_name):
    list_instructs = []
    for i in range(0, len(selected_lists_as_lists), n):
        request_3 = create_request_prompt_3(response_1,json_sample,selected_lists_as_lists[i:i+n],list_number_of_runs[i:i+n])
        response_3 = send_request(request_3,chatgpt35_model_name, temperature=0.3,max_tokens=8000)
        print("\n\nduring stage 3\n\n",response_3)
        instruct_list = ast.literal_eval(response_3)
        list_instructs = list_instructs + instruct_list
        
    with open(f'{folder_name}/stage_3.txt', 'w') as file:
        file.write(str(list_instructs))
    return list_instructs

def stage_4(list_instructs,folder_name):
    synthetic_date = []
    for instruct in list_instructs:
        request_4 = create_request_prompt_4(instruct)
        response_4 = send_request(request_4,chatgpt35_model_name, temperature=0.4)
        print("during stage 4", response_4)
        data_list = ast.literal_eval(response_4)
        synthetic_date = synthetic_date + data_list
    with open(f'{folder_name}/stage_4.txt', 'w') as file:
        file.write(str(synthetic_date))
    
    synthetic_df = pd.DataFrame(synthetic_date)
    synthetic_df.to_csv(f'{folder_name}/synthetic_complete_data.csv', index=False)
    return synthetic_df
    
def create_synthetic_table(folder_name, df, table_context, number_of_rows=100):
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)
    print("start")
    int_df_col_count, json_sample = stage_0(df)
    print("stage 1 start")
    response_1, column_options = stage_1(json_sample,table_context,folder_name)
    print("stage 1 end","stage 2 start")
    response_2 = stage_2(response_1,folder_name)
    print("stage 2 end","stage 2.5 start")
    selected_lists_as_lists, list_number_of_runs = stage_2_5(response_2, int_df_col_count,column_options,number_of_rows,folder_name)
    print("stage 2.5 end","stage 3 start")
    list_instructs = stage_3(10,selected_lists_as_lists,response_1,json_sample,list_number_of_runs,folder_name)
    print("stage 3 end","stage 4 start")
    synthetic_df = stage_4(list_instructs,folder_name)
    print("stage 4 end","end")
    return synthetic_df

#df_sample = pd.read_csv('synthetic_data.csv')
# int_df_col_count, json_sample = stage_0(df_sample)
#table_context = "It is currently April 2024 and the data is based on residents in the UK. "
# response_1, column_options = stage_1(json_sample,table_context)
# print(response_1,"\n\n\n")
# response_2 = stage_2(response_1)
# print(response_2)
# selected_lists_as_lists, list_number_of_runs = stage_2_5(response_2, int_df_col_count,column_options,number_of_rows=100)
# list_instructs = stage_3(20,selected_lists_as_lists,response_1,json_sample,list_number_of_runs)
#test = create_synthetic_table(df_sample, table_context, number_of_rows=100)
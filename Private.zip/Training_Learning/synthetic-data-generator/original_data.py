from functions.llm import send_request, chatgpt432k_model_name, create_request
from stages import create_synthetic_table
import pandas as pd
import time, os

list_dicts_original_tables = [{"table_name": "Party",
  "fields":"""
- PartyID: INT, Primary Key, Unique, Not Null. Description: Unique identifier for each party.
- FirstName: VARCHAR(255), Not Null. Description: First name of the party.
- LastName: VARCHAR(255), Not Null. Description: Last name of the party.
- DateOfBirth: DATE, Not Null. Description: Date of birth of the party.
- Address: VARCHAR(500), Not Null. Description: Residential address of the party.
- Email: VARCHAR(255), Unique, Not Null. Description: Email address of the party. Must be unique.
- Phone: VARCHAR(20), Not Null. Description: Contact phone number of the party.
""",
  "table_description": "Stores information about each party, including personal details.",
  "number_of_records": 100,
  "sample_data": [
    {"PartyID": 1, "FirstName": "John", "LastName": "Doe", "DateOfBirth": "1980-05-15", "Address": "123 Elm Street, Springfield, IL", "Email": "johndoe@example.com", "Phone": "555-1234"},
    {"PartyID": 2, "FirstName": "Jane", "LastName": "Smith", "DateOfBirth": "1975-07-20", "Address": "456 Oak Avenue, Anytown, CA", "Email": "janesmith@example.com", "Phone": "555-5678"},
    {"PartyID": 3, "FirstName": "Alice", "LastName": "Johnson", "DateOfBirth": "1990-12-31", "Address": "789 Pine Road, Smallville, NY", "Email": "alicejohnson@example.com", "Phone": "555-9876"}
]},
 
{"table_name": "Transaction",
  "fields":"""
- TransactionID: INT, Primary Key, Unique, Not Null. Description: Unique identifier for each transaction.
- AccountID: INT, Foreign Key (Account), Not Null. Description: References AccountID from Account Table.
- TransactionType: VARCHAR(50), Not Null. Description: Type of transaction (Deposit, Withdrawal, Transfer, etc.).
- Amount: DECIMAL(15,2), Not Null. Description: Amount involved in the transaction.
- TransactionDate: DATE, Not Null. Description: Date when the transaction occurred.
""",
  "table_description": "Records details of financial transactions for accounts.",
  "number_of_records": 400,
  "sample_data": [
    {"TransactionID": 1001, "AccountID": 101, "TransactionType": "Deposit", "Amount": 200.00, "TransactionDate": "2022-03-15", "Description": "Monthly salary deposit"},
    {"TransactionID": 1002, "AccountID": 102, "TransactionType": "Withdrawal", "Amount": 150.00, "TransactionDate": "2022-03-20", "Description": "ATM withdrawal"},
    {"TransactionID": 1003, "AccountID": 103, "TransactionType": "Transfer", "Amount": 500.00, "TransactionDate": "2022-04-01", "Description": "Rent payment"}
]},

{"table_name": "Card",
  "fields":"""
- CardID: INT, Primary Key, Unique, Not Null. Description: Unique identifier for each card.
- PartyID: INT, Foreign Key (Party), Not Null. Description: References PartyID from Party Table.
- CardType: VARCHAR(50), Not Null. Description: Type of card (Debit, Credit).
- CardNumber: VARCHAR(19), Unique, Not Null. Description: Card number. Must be unique.
- ExpiryDate: DATE, Not Null. Description: Expiry date of the card.
- CVV: INT, Not Null. Description: CVV number of the card.
""",
  "table_description": "Information about each card issued to parties, including card numbers.",
  "number_of_records": 120,
  "sample_data": [
    {"CardID": 201, "PartyID": 1, "CardType": "Credit", "CardNumber": "4532876503214569", "ExpiryDate": "2025-12-31", "CVV": 123},
    {"CardID": 202, "PartyID": 2, "CardType": "Debit", "CardNumber": "4567890342123456", "ExpiryDate": "2024-11-30", "CVV": 456},
    {"CardID": 203, "PartyID": 3, "CardType": "Credit", "CardNumber": "4987654321098765", "ExpiryDate": "2023-10-15", "CVV": 789}
]},

{"table_name": "Loan",
  "fields":"""
- LoanID: INT, Primary Key, Unique, Not Null. Description: Unique identifier for each loan.
- PartyID: INT, Foreign Key (Party), Not Null. Description: References PartyID from Party Table.
- LoanType: VARCHAR(50), Not Null. Description: Type of loan (Mortgage, Personal, Auto).
- LoanAmount: DECIMAL(15,2), Not Null. Description: Total amount of the loan.
- InterestRate: DECIMAL(5,2), Not Null, CHECK (InterestRate > 0). Description: Interest rate applied to the loan.
- Term: INT, Not Null. Description: Term of the loan in months or years.
- ApprovalDate: DATE, Not Null. Description: Date when the loan was approved.
""",
  "table_description": "Stores loan details for parties, including amount and interest rate.",
  "number_of_records": 90,
  "sample_data": [
    {"LoanID": 301, "PartyID": 1, "LoanType": "Mortgage", "LoanAmount": 250000.00, "InterestRate": 3.5, "Term": 360, "ApprovalDate": "2020-06-15"},
    {"LoanID": 302, "PartyID": 2, "LoanType": "Personal", "LoanAmount": 5000.00, "InterestRate": 6.5, "Term": 24, "ApprovalDate": "2021-08-20"},
    {"LoanID": 303, "PartyID": 3, "LoanType": "Auto", "LoanAmount": 15000.00, "InterestRate": 4.0, "Term": 60, "ApprovalDate": "2022-04-01"}
]},

{"table_name": "Branch",
  "fields":"""
- BranchID: INT, Primary Key, Unique, Not Null. Description: Unique identifier for each branch.
- PartyID: INT, Foreign Key (Party), Unique, Not Null. Description: References PartyID from Party Table. Unique for 1-to-1 relationship.
- BranchName: VARCHAR(255), Not Null. Description: Name of the branch.
- Location: VARCHAR(255), Not Null. Description: Physical location of the branch.
""",
  "table_description": "Details of bank branches, including location.",
  "number_of_records": 30,
  "sample_data": [
    {"BranchID": 401, "PartyID": 1, "BranchName": "Downtown", "Location": "123 City Center, Metropolis"},
    {"BranchID": 402, "PartyID": 2, "BranchName": "Uptown", "Location": "456 Suburb Road, Metropolis"},
    {"BranchID": 403, "PartyID": 3, "BranchName": "Eastside", "Location": "789 Eastside Blvd, Metropolis"}
]},

{"table_name": "Account",
  "fields":"""
- AccountID: INT, Primary Key, Unique, Not Null. Description: Unique identifier for each account.
- PartyID: INT, Foreign Key (Party), Not Null. Description: References PartyID from Party Table.
- AccountType: VARCHAR(50), Not Null. Description: Type of account (Savings, Current, Loan, Checking, etc.).
- Balance: DECIMAL(15,2), Not Null. Description: Current balance of the account.
- OpenDate: DATE, Not Null. Description: Date when the account was opened.
- Status: VARCHAR(50), Not Null. Description: Current status of the account (Active, Inactive, Closed).
- LimitAmount: DECIMAL(15,2), Not Null. Description: The limit amount for the account, if applicable.
""",
  "table_description": "Contains details about each account, including type and balance.",
  "number_of_records": 120,
  "sample_data": [
    {"AccountID": 101, "PartyID": 1, "AccountType": "Checking", "Balance": 1200.50, "OpenDate": "2010-06-15", "Status": "Active", "LimitAmount": 5000.00},
    {"AccountID": 102, "PartyID": 2, "AccountType": "Savings", "Balance": 5600.00, "OpenDate": "2012-08-20", "Status": "Active", "LimitAmount": 10000.00},
    {"AccountID": 103, "PartyID": 3, "AccountType": "Loan", "Balance": -25000.00, "OpenDate": "2018-12-01", "Status": "Inactive", "LimitAmount": 50000.00}
]}

]

str_list_dicts_original_tables = str(list_dicts_original_tables)

table_relationships = """
- Party to Account: One-to-many (A party can have multiple accounts).
- Account to Transaction: One-to-many (An account can have multiple transactions).
- Party to Card: One-to-many (A party can have multiple cards).
- Party to Loan: One-to-many (A party can have multiple loans).
- Party to Branch: One-to-one (Each party is associated with exactly one branch).
"""
example_dictionary = "{'table_name':'Customer','relations':'There is a StoreID field which is referencing the Store Table. Given there is an Address Field in this Customer table and the Store table, for each row of data in the Customer table, it should only reference a store which has the same or similar location Address Field','prompt':'Based on the relations identified, and based on the sample data of the Store Table, the Customers table storeID should reference based on the following from the Store table: ID 1 with Address location California, ID 2 with Address location London, ID 3 with Address location Tokyo.'}"
system_prompt = f"""
You are a python data structures expert and data engineering expert, specialised in understanding relations and influences from different tables in a database.

The user will submit a list of dictionaries, where each dictionary describes a table, including schema and sample data and they will also submit text describing the relations between these tables. Starting with the table which has no foreign keys, you will analyse this information and output a list of dictionaries, with each dictionary correlating to one of the user described tables. 
Each dictionary will contain the following:
- a 'table_name' key which has a string value containing the table's name
- a 'relations' key which has a string value containing a description on the fields in this table which reference another table and any relevant information for when building this table. For example, if the customer table contains a location field and a storeID field which references the store table and in the store table there is a location field, these must be accurately referenced in this table, so each store referenced is in the same location as the customer.
- a 'prompt' key which has a string value containing a description of any important relations identified from this table's relations key as well as any other tables which reference this table.
 
Example of a dictionary:
{example_dictionary}

Keep descriptions and relations and data identified consistent across all tables.
"""

user_prompt = f"""
# List of dictionaries describing each table
{str_list_dicts_original_tables}

# Relations between each table
{table_relationships}

# Request
I will pay a large bonus if you analyse the different tables and their fields to identify and explain how different tables relate to each other (maybe include wider context) and mention the specific data from the sample data. Think step by step.
"""

# request = create_request(system_prompt,user_prompt)

# response = send_request(request, chatgpt432k_model_name, temperature=0.5)

# print(response)

system_prompt = """
You are a data engineer who is an expert in python and pandas. The user will give the details of a number of tables and your role is to analyse the tables based on the fields, primary keys 
and foreign keys and number of records for each table. You will then respond with a python dictionary where the keys are table names and the value is another dictionary, where the keys are column names for the Primary Key IDs and Foreign Key IDs
and the values are the number of rows. For example, if table a has a count of 100 rows and it references table b, which has a count of 20 rows, then in the dictionary for table a, the primary key value should be 100 and the foreign key value should be 20.
Your output should only be the dictionary.
Structure:
{table_name: {primary_key_column_name: number, foreign_key_column_name: number}}
"""

user_prompt = ""
n = 0
for table in list_dicts_original_tables:
    n += 1
    table_prompt = f"""
## Table {n}
### Table Name: 
{table["table_name"]}

### Table Fields:
{table["fields"]}

### Table Description:
{table["table_description"]}

### Number of Records in Table:
{table["number_of_records"]}

### Sample Table Data:
{table["sample_data"]}


"""
    user_prompt = user_prompt + table_prompt
    
# request = create_request(system_prompt,user_prompt)

# response = send_request(request, chatgpt432k_model_name, temperature=0.5)

# print(response)
for dictionary in list_dicts_original_tables:
    df = pd.DataFrame(dictionary["sample_data"])
    table_context = dictionary["table_description"]
    number_of_rows = dictionary["number_of_records"]
    folder_name = dictionary["table_name"]
    if os.path.exists(f'{folder_name}/synthetic_complete_data.csv'):
        continue
    max_attempts = 5

    for attempt in range(max_attempts):
        try:
            create_synthetic_table(folder_name,df,table_context,number_of_rows)
            print("Function succeeded.")
            break  # Exit the loop if the function succeeds
        except Exception as e:
            print(f"Attempt {attempt + 1} failed with error: {e}")
            if attempt < max_attempts - 1:  # Check if it's the last attempt
                print("Waiting 30 seconds before the next attempt...")
                time.sleep(30)  # Pause execution for 30 seconds
            else:
                print("Maximum attempt limit reached.")
    else:
        # This part runs if the loop exits without breaking (i.e., all attempts failed)
        print("All attempts failed. No more retries.")
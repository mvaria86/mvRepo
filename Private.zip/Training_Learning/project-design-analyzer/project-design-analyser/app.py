'''A simple streamlit application for creating a prompt in the ui, uploading an image and 
    prompt to OpenAI, and fetching a response'''
import base64
import streamlit as st
from openai import AzureOpenAI

def local_image_to_data_url(image_path):
    '''Make this image computer readable'''
    mime_type = 'image/png'
    base64_encoded_data = base64.b64encode(image_path.getvalue()).decode('utf-8')

    return f"data:{mime_type};base64,{base64_encoded_data}"

def openai_call(client, deployment_name, text_input, prompt, data_url):
    '''The OpenAI API call, used to upload the image and generate a response'''
    response = client.chat.completions.create(
        model=deployment_name,
        messages=[
        {
            "role": "system", 
            "content": f"{text_input}" 
        },
        {
            "role": "user", 
            "content": [
	            {
	                "type": "text",
	                "text": prompt
	            },
	            {
	                "type": "image_url",
	                "image_url": {
                        "url": f"{data_url}"
                    }
                }
           ]
        }
    ],
        max_tokens=1000
        )
    return response.choices[0].message.content

def main():
    '''Where the streamlit application is defined and run'''
    st.title("Image Description")
    image_path = st.file_uploader('Image file')
    if image_path:
        st.sidebar.image(image_path,caption= 'Uploaded Image')
        placeholder = '''You are a helpful assistant. Your main task is to describe the
        uploaded business process diagram. \nSplit your response into 3 sections:\n- An 
        explanation of the diagram, \n-Things that you think are good about the diagram
        , \n-Potential improvements'''
        user_prompt = st.sidebar.text_area("Create your prompt", value=placeholder,  height=300)
        placeholder = user_prompt
        data_url = local_image_to_data_url(image_path)
        deployment_name='testboi'
        client = AzureOpenAI(
            api_key = st.secrets["API_KEY"],
            api_version="2023-12-01-preview",
            azure_endpoint = st.secrets["API_ENDPOINT"]
        )
        # st.write(data_url[:100])
        desc = st.button('Submit')
        if desc:
            summary = openai_call(client, deployment_name, placeholder, user_prompt, data_url)
            st.write(summary)

if __name__ == "__main__":
    main()

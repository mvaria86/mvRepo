require("dotenv").config();
const express = require("express");
const { Configuration, OpenAIApi } = require("openai");
var cors = require("cors");

const app = express();
app.use(express.json());
bodyParser = require("body-parser");
app.use(cors());
app.use(bodyParser.json());

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

const port = process.env.PORT || 5000;

app.get("/ask/:data", async (req, res) => {
  console.log("params", req.params);
  const prompt = atob(req.params.data);
  console.log(prompt);
  try {
    // if (prompt == null) {
    //   return res.status(400).json({ message: "bad reqeust" });
    // }
    const response = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
    });
    const completion = response.data.choices[0].message.content;
    return res.status(200).json({ message: completion });
    return res.status(200).json({
      success: true,
      message: completion,
    });
  } catch (error) {
    console.log("error", error.message);
  }
});

app.get("/test", async (req, res) => {
  return res.status(200).json({
    success: true,
    message: "i am test",
  });
});
app.get("/tell", async (req, res) => {
  return res.status(200).json({
    success: true,
    message: "get was good and that",
  });
});

app.listen(port, () => console.log(`Server is running on port ${port}!!`));

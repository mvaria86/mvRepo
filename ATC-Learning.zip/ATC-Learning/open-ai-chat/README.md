Install nodemon  
get your API key and stick it in an env file  
.env  
OPENAI_API_KEY=  
POST_ASK_URL=  
  
nodemon index.js  

open index.html in google chrome

click ask a question
allow the camera

Ask a question

Make sure your volume is turned up

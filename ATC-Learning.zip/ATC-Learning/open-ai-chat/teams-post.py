import urllib3
import json


class TeamsWebhookException(Exception):
    """custom exception for failed webhook call"""

    print(Exception)
    pass


class ConnectorCard:
    def __init__(self, hookurl, http_timeout=60):
        self.http = urllib3.PoolManager()
        self.payload = {}
        self.hookurl = hookurl
        self.http_timeout = http_timeout

    def text(self, mtext):
        self.payload["text"] = mtext
        return self

    def send(self):
        headers = {"Content-Type": "application/json"}
        r = self.http.request(
            "POST",
            f"{self.hookurl}",
            body=json.dumps(self.payload).encode("utf-8"),
            headers=headers,
            timeout=self.http_timeout,
        )
        if r.status == 200:
            print("Message sent successfully")
            return True
        else:
            print("it failed")
            raise TeamsWebhookException(r.reason)


if __name__ == "__main__":
    # Put your webhook link in below. and change the message before its sent out
    # to get a webhook, go to your teams channel (might have to be an admin). right click on general, click "manage this channel". Edit the connectors. Click on incoming webhook, add/install.  Copy the url and paste it below
    myTeamsMessage = ConnectorCard(
        "https://accenture.webhook.office.com/webhookb2/f07bd071-4d42-46c8-bd46-e281ae557a0e@e0793d39-0939-496d-b129-198edd916feb/IncomingWebhook/4721aa175e4945839f512111222955b3/12ea5b9f-7c85-408d-a33f-827efe5f0da8"
    )
    myTeamsMessage.text("Hello, im a test webhook and im wondering if you got this.")
    myTeamsMessage.send()

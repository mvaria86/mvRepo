const chatbot = document.getElementById("chatbot");
const conversation = document.getElementById("conversation");
const inputForm = document.getElementById("input-form");
const inputField = document.getElementById("input-field");
// require("dotenv").config();

const fetchData = async (url, data) => {
  console.log("in fetch data");
  console.log("DATA", data);
  checkLocalStorage();
  appendLocalStorage(data);
  const basevalue = btoa(
    // "please answer this question in the context of Website development in Sakinaka Mumbai, and consider the chat conversation so far of: " +
    // "please answer this question in the context of Website development in Sakinaka Mumbai, and consider the chat conversation so far of: " +
    getLocalStorage("convohistory").join(".") +
      ".  This is the question: " +
      data
    // +
    // ". keep answers short, and under 30 words.  The answer should be related to the United Kingdom Only"
  );
  let response = await fetch(url + basevalue, {
    method: "GET", // Specify the HTTP method
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
  });

  const message = await response.json();
  appendLocalStorage(message.message);
  return message.message;
};

const tellData = async () => {
  const response = await fetch("http://localhost:5000/tell", {
    method: "GET", // Specify the HTTP method
  });
  return response;
};

const getLocalStorage = () => {
  return JSON.parse(localStorage.getItem("convohistory"));
};

const checkLocalStorage = () => {
  if (!localStorage.getItem("convohistory")) {
    localStorage.setItem("convohistory", JSON.stringify([]));
  }
};

const appendLocalStorage = (response) => {
  let data = JSON.parse(localStorage.getItem("convohistory"));
  data.push(response);
  localStorage.setItem("convohistory", JSON.stringify(data));
};

const deteleLocalStorage = () => {
  localStorage.removeItem("convohistory");
};

const runSpeechRecognition = async () => {
  // get output div reference
  var output = document.getElementById("output");
  // get action element reference
  var action = document.getElementById("action");
  // new speech recognition object
  var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition;
  var recognition = new SpeechRecognition();

  // This runs when the speech recognition service starts
  recognition.onstart = function () {
    action.innerHTML = "<small>listening, please speak...</small>";
  };

  recognition.onspeechend = function () {
    action.innerHTML = "<small>stopped listening, hope you are done...</small>";
    recognition.stop();
  };

  // This runs when the speech recognition service returns result
  recognition.onresult = function (event) {
    var transcript = event.results[0][0].transcript;
    var confidence = event.results[0][0].confidence;
    output.innerHTML =
      "<b>Text:</b> " +
      transcript +
      "<br/> <b>Confidence:</b> " +
      confidence * 100 +
      "%";
    const currentTime = new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
    let message = document.createElement("div");
    message.classList.add("chatbot-message", "user-message");
    message.innerHTML = `<p class="chatbot-text" sentTime="${currentTime}">${transcript}</p>`;
    conversation.appendChild(message);
    output.classList.remove("hide");

    fetchData("http://localhost:5000/ask/", transcript).then((answer) => {
      let text = answer;
      console.log(text);

      let message = document.createElement("div");
      message.classList.add("chatbot-message", "chatbot");
      message.innerHTML = `<p class="chatbot-text" sentTime="${currentTime}">${text}</p>`;
      conversation.appendChild(message);
      output.classList.remove("hide");
      const scrollToBottom = (id) => {
        const element = document.getElementById(id);
        element.scrollTop = element.scrollHeight;
      };
      scrollToBottom("conversation");
      // Create a new SpeechSynthesisUtterance object
      let utterance = new SpeechSynthesisUtterance();
      // Set the text and voice of the utterance
      utterance.text = text;

      utterance.voice = window.speechSynthesis.getVoices()[0];
      // Speak the utterance
      window.speechSynthesis.speak(utterance);
    });
  };

  // start recognition
  recognition.start();
};

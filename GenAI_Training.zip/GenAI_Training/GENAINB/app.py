import openai
import streamlit as st
from streamlit_chat import message
from openai import AzureOpenAI

# Open API key

#openai.api_key = st.secrets["OPEN_API_KEY"]
#openai.api_key = "e21f323f54f14baab3e5931d37908b9b"
tokens_model = "gpt-35-turbo"
embeddings_model = "genai-training-text-embedding-ada-002"
chatgpt35_model_name = "genai-training-gpt-35-turbo"

# Generating responses from the api
client = AzureOpenAI(
    api_key="e21f323f54f14baab3e5931d37908b9b",
    api_version="2024-02-15-preview",
    azure_endpoint="https://oai-genai-training-2310.openai.azure.com/"
)

list_of_uk_priministers = """
You are AI assistant to help students, teachers and parents associated to Fenchurch Street School.
Fenchurch Street​ school is a secondary school located in London. They have students right from Year 7 to Year 11.
In total, there are 10 classes accomodating 300 students.
There are multiple classes in school on 3 floors.
Year 7 class is located on ground floor.
Years 8 class is located on first floor.
"""

# We can also add more parameters
def generate_response(user_message):
    query = f"""Use the information provided in the wikipedia extract below to answer questions on class details,
    If the answer cannot be found, write "I don't know."

    Additional information:
    \"\"\"
    {list_of_uk_priministers}
    \"\"\"    
    """

    
    #Question: Tell me about Fenchurch Street School?
    completion = client.chat.completions.create(
        model=chatgpt35_model_name,
        messages=[
            {'role': 'system', 'content': 'You answer questions about Fenchurch Street School.'},
            {'role': 'user', 'content': user_message},
        ], 
        temperature=1,
        max_tokens=1024,
        top_p=0.5,
        frequency_penalty=0,
        presence_penalty=0
    )
    return completion.choices[0].message.content

# Creating the chatbot interfaces

st.title("FENCHY - Fenchurch Street​ School Assistant")

# Storing the input

if 'generated' not in st.session_state:
    st.session_state["generated"] = []
if 'past' not in st.session_state:
    st.session_state["past"] = []

# Creating a function that returns the user's input from a text input field

def get_text():
    input_text = st.text_input("You : ", "Hi Fenchy, who are you?", key = "input")
    return input_text

# We will generate response using the 'generate response' function and store into variable called output
def new_chat():
    save = []
    for i in range(len(st.session_state['generated'])-1, -1, -1):
        save.append("User:" + st.session_state["past"][i])
        save.append("Bot:" + st.session_state["generated"][i])        
    st.session_state["stored_session"].append(save)
    st.session_state["generated"] = []
    st.session_state["past"] = []
    st.session_state["input"] = ""

st.sidebar.button("New Chat", on_click=new_chat)
user_input = get_text()

if user_input:
    output = generate_response(user_input)

    # Store the output
    st.session_state.past.append(user_input)
    st.session_state.generated.append(output)


# Finally we display the chat history

if st.session_state['generated']:

    for i in range(len(st.session_state['generated']) -1, -1, -1):
        message(st.session_state["generated"][i], key=str(i))
        message(st.session_state["past"][i], is_user=True, key=str(i) + '_user')
# In the terminal/command prompt enter the following code: streamlit run 'file_name'

# Import python packages
import streamlit as st
from openai import AzureOpenAI

# Define GPT Model Name
chatgpt35_model_name = "genai-training-gpt-35-turbo"
#chatgpt35_model_name = "gpt-4"

# Define Client details
chat_client = AzureOpenAI(
    api_key="e21f323f54f14baab3e5931d37908b9b",
    api_version="2024-02-15-preview",
    azure_endpoint="https://oai-genai-training-2310.openai.azure.com/"
)


# Python function to send a message to the GPT Chat model
def send_request(request_message):
    response = chat_client.chat.completions.create(
        model=chatgpt35_model_name,
        messages=request_message,
        temperature=0.7,
        max_tokens=500,
        top_p=0.95,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None)

    return response.choices[0].message.content

# Python function to create message format for sending to GPT Chat Model
def create_request(system_prompt, user_prompt):
    request = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}]
    
    return request

# Creates Title using markdown code
st.markdown("# Basic Gen AI Demo")

# Creates an input box for user
question = st.text_area(label='What is the question?')

# Creates button for user to click which will send the message to the GPT Chat Model
if st.button('Generate response'):
    message = create_request("You are an assistant answering questions.", question)
    answer = send_request(message)
    st.text_area('Answer created: ', answer)
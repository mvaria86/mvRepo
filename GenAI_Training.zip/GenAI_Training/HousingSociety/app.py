from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential
import pandas as pd

# Function to read the Excel sheet into a DataFrame
def read_excel(file_path):
    return pd.read_excel(file_path)

# Function to search for information based on keywords using Azure Text Analytics
def search_information_azure(text, keyword):
    # Azure Text Analytics configuration
    key = "5eb7910523a2402d91b3e4e538aa118f"
    endpoint = "https://boi-openai.openai.azure.com/"
    credential = AzureKeyCredential(key)
    client = TextAnalyticsClient(endpoint=endpoint, credential=credential)

    # Split text into smaller chunks (e.g., sentences)
    documents = [text]

    # Analyze sentiment for each document
    result = client.analyze_sentiment(documents, show_stats=False)
    if result.is_error:
        print("Error:", result.error)
        return None

    # Extract sentences with positive sentiment containing the keyword
    positive_sentences = []
    for idx, doc in enumerate(result):
        if doc.sentiment == "positive" and keyword in documents[idx]:
            positive_sentences.append(documents[idx])

    return positive_sentences

# Main function
def main():
    # Read the Excel sheet
    excel_file = "housing_society_members.xlsx"  # Replace with your file path
    df = read_excel(excel_file)

    # Prompt user for a keyword query
    keyword = input("Enter a keyword: ")

    # Combine text from DataFrame into a single string
    text = " ".join(df.apply(lambda x: " ".join(x.astype(str)), axis=1))

    # Search for information based on the keyword using Azure Text Analytics
    search_result = search_information_azure(text, keyword)

    # Display search results
    if search_result:
        print("Search Results:")
        for sentence in search_result:
            print("-", sentence)
    else:
        print("No matching information found.")

if __name__ == "__main__":
    main()
